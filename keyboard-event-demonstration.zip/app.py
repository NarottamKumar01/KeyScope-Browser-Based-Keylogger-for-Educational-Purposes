import http.server
import socketserver
import webbrowser
import threading
import socket
import sys
import os

# Default port
PORT = 8000

# Try to find a free port starting from 8000
def find_free_port(start_port):
    port = start_port
    while port < start_port + 100:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(('localhost', port))
                return port
            except socket.error:
                port += 1
    return start_port

def run_server(port):
    handler = http.server.SimpleHTTPRequestHandler
    # Serve files from the directory containing this script
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    with socketserver.TCPServer(('localhost', port), handler) as httpd:
        print(f"Serving Keyboard Event Demonstration at http://localhost:{port}")
        print("Press Ctrl+C in the terminal to stop the server.")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server...")
            sys.exit(0)

def main():
    port = find_free_port(PORT)
    url = f"http://localhost:{port}"
    
    # Start server in a separate thread so we can launch browser concurrently
    server_thread = threading.Thread(target=run_server, args=(port,), daemon=True)
    server_thread.start()
    
    # Give the server a small moment to start, then open the web browser
    print(f"Launching web browser at {url}...")
    webbrowser.open(url)
    
    # Keep the main thread alive to listen to exit signal
    try:
        while True:
            server_thread.join(timeout=1.0)
            if not server_thread.is_alive():
                break
    except KeyboardInterrupt:
        print("\nExiting application...")
        sys.exit(0)

if __name__ == "__main__":
    main()
